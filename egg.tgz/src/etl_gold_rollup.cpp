// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Roll up gold layer\n", stdout);
  return lionss_run_workload("etl_gold_rollup");
}
