// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Decode B-format\n", stdout);
  return lionss_run_workload("ambisonicb");
}
