// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "Push WAL archive");
  std::fflush(stdout);
  return lionss_run_workload("WalgPush");
}
