// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Optimize windward leg"); }
int main(){
  announce();
  return lionss_run_workload("windward");
}
