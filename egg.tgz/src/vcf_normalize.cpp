// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Normalize indels\n", stdout);
  return lionss_run_workload("vcf_normalize");
}
