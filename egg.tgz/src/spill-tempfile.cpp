// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Spill to tempfile"); }
int main(){
  announce();
  return lionss_run_workload("spill-tempfile");
}
